#!/bin/bash

EXE=./q2

# N 从 512 开始，每次 ×2
Ns=(512 1024 2048 4096 8192 16384 32768 65536 131072 262144)

# 输出到一个文本文件，后面画图用
OUT="q2_times.txt"
echo "N CPU_ms GPU_ms abs_diff" > "$OUT"

for N in "${Ns[@]}"; do
  echo "Running N=$N ..."
  # 只取最后一行（包含 N CPU GPU diff）
  line=$($EXE "$N" | tail -n 1)
  echo "$line"
  echo "$line" >> "$OUT"
done
