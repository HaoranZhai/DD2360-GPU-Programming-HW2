import numpy as np
import matplotlib
matplotlib.use("Agg")  # 使用无窗口后端
import matplotlib.pyplot as plt

NUM_BINS = 4096
BLOCK_DIM = 256
Ns = [1024, 10240, 102400, 1024000]
dists = ["uniform", "normal"]  # 对应文件名里的关键字


def load_hist(dist, N):
    fname = f"hist_{dist}_{N}.txt"
    print(f"Loading {fname} ...")
    data = np.loadtxt(fname, dtype=np.uint32)
    if data.size != NUM_BINS:
        raise ValueError(f"{fname}: expected {NUM_BINS} bins, got {data.size}")
    return data


def plot_for_distribution(dist):
    fig, axes = plt.subplots(2, 2, figsize=(14, 8), sharex=True, sharey=True)
    fig.suptitle(f"Histogram from CUDA code ({dist} distribution)")

    for idx, N in enumerate(Ns):
        row, col = divmod(idx, 2)
        ax = axes[row, col]

        hist = load_hist(dist, N)
        grid_dim = (N + BLOCK_DIM - 1) // BLOCK_DIM

        ax.bar(np.arange(NUM_BINS), hist, width=1.0)
        ax.set_title(f"N={N}, block={BLOCK_DIM}, grid={grid_dim}")
        ax.set_xlabel("bin")
        ax.set_ylabel("count (clamped at 127)")

        # 如果图太密，可以只看中间部分，打开下面两行：
        # center = NUM_BINS // 2
        # ax.set_xlim(center - 200, center + 200)

    plt.tight_layout()

    out_name = f"{dist}.png"
    print(f"Saving figure to {out_name}")
    plt.savefig(out_name, dpi=300, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    # uniform
    plot_for_distribution("uniform")
    # normal
    plot_for_distribution("normal")
